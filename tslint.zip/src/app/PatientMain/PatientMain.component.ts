import {Component} from "@angular/core"

@Component({
  selector:'patient-main',
  templateUrl: './PatientMain.component.html'
  })

export class PatientMainComponent{


}
