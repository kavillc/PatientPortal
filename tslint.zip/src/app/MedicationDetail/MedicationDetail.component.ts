import { Component, OnInit } from '@angular/core';

import {MedicationDetail} from './MedicationDetail.model'
@Component({
  selector: 'app-medication-detail',
  templateUrl: './MedicationDetail.component.html',
  styleUrls: ['./MedicationDetail.component.css']
})
export class MedicationDetailComponent implements OnInit {
medications:MedicationDetail[]=[
 new MedicationDetail(
 57301,
 1742820,
 'TRANEXAMIC ACID 650MG TAB',
 'Mildred Baylortravis',
 'Ruby  Ederi',
 'Framework Pharmacy',
 new Date('2015-09-16').toLocaleString('en-US'),
 	0,
  new Date('2015-10-16').toLocaleString('en-US'),
  '3 times a day',
  '123-456-7890',
  '123 Main Street',
  3.00,
  180.00,
  30.00,
  new Date('2015-09-15').toLocaleString('en-US'),
  new Date('2015-10-15').toLocaleString('en-US'),
  13720300059),
  new MedicationDetail(
  57637,
  1742826,
  'HARVONI 90/400MG TABB',
  'Harold Franklin',
  'Latrisha  Futscher',
  'Framework Pharmacy',
  new Date('2015-09-16').toLocaleString('en-US'),
  	0,
   new Date('2015-10-16').toLocaleString('en-US'),
   '3 times a day',
   '123-456-7890',
   '123 Main Street',
   3.00,
   180.00,
   30.00,
   new Date('2015-09-15').toLocaleString('en-US'),
   new Date('2015-10-15').toLocaleString('en-US'),
   13720300059)


];
  constructor() { }

  ngOnInit() {
  }

}
