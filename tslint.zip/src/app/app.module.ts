import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'

import{PatientMainComponent} from './PatientMain/PatientMain.component';


import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { MedicationDetailComponent } from './MedicationDetail/MedicationDetail.component';

@NgModule({
  declarations: [
    AppComponent,
    PatientMainComponent,
    HeaderComponent,
    MedicationDetailComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
