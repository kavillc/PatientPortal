import {Http,Response} from '@angular/http'
import {Observable} from 'rxjs'
import 'rxjs/add/operator/map'
import 'rxjs/add/operator/toPromise'
import {MedicationDetail} from './MedicationDetail.model'
import {Injectable} from '@angular/core';
import 'rxjs/Rx';
@Injectable()
export class MedicationDetailService{
  medicationDetail:MedicationDetail[];
  constructor (private http:Http){}
  url="http://localhost:3095/api/PatientMedication/5";
  private params= new URLSearchParams();
 // this.params.set('',patientId);

  public getMedicationWithObservable()
  {
    return this.http.get('http://localhost/aspnet_client/PatientPortal/api/PatientMedication/1')
    .map(response => response.json());
  }
}
