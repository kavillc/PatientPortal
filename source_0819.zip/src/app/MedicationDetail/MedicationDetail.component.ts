import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { Http, Response } from '@angular/http';
import { MedicationDetailService } from './MedicationDetail.service';

import {MedicationDetail} from './MedicationDetail.model'
@Component({
  selector: 'app-medication-detail',
  templateUrl: './MedicationDetail.component.html',
  providers: [MedicationDetailService],
  styleUrls: ['./MedicationDetail.component.css']
})
export class MedicationDetailComponent implements OnInit {

  medications: MedicationDetail[];
  subscription: Subscription;
  patientId:number=1742817;
  temp:Date=new Date();
  private dateRange=this.temp.setDate(this.temp.getDate()-770);


 constructor(private medicationService: MedicationDetailService){} ;
   ngOnInit(){
    this.medicationService.getMedicationWithObservable().subscribe(medications => {
        this.medications = medications
       });
}
}
